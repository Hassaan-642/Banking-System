

#ifndef OOPLAB_FINAL_ACCOUNTHOLDER_H
#define OOPLAB_FINAL_ACCOUNTHOLDER_H

#include "Person.h"
#include"CCardType.h"
#include"Accounttype.h"
#include"Transaction.h"
class AccountHolder: public Person {
protected:
    long int balance;
    Accounttype* AccType;
    int Acctype;
    int CardType;
    CCardType* Cdetails;
    int interest;
    double Deposit;
    double WithDraw;
public:
    AccountHolder();

    ~AccountHolder();

    const Accounttype &getAccType() const;

    void setAccType(int actype);

    int getAcctype() const;



    int getCardType() const;

    void setCardType(int cardType);
    void setDeposit(double);
    double getDeposit();
    void setMini
    void getMiniStatement()const;
    void Deposit();
    void setWithDraw(double);
    double getWithDraw();
    void getTransactionHistory();
    void setAccType(Accounttype *accType);

};


#endif //OOPLAB_FINAL_ACCOUNTHOLDER_H
