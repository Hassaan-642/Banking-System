//
// Created by UM3R on 24/05/2022.
//

#ifndef OOPLAB_FINAL_LOCALCARD_H
#define OOPLAB_FINAL_LOCALCARD_H
#include "CCardType.h"

class LocalCard :public CCardType{
public:
    virtual int getMonthlyInterest();

    LocalCard();
};


#endif //OOPLAB_FINAL_LOCALCARD_H
