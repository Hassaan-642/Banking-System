

#include "CheckingAccount.h"

int CheckingAccount:: getTotalInterest()
{
    return 21321;
}

CheckingAccount::CheckingAccount(int minAccBalance, int totalInterest, int govtTaxIntrst) : Accounttype(minAccBalance,
                                                                                                        totalInterest,
                                                                                                        govtTaxIntrst) {}
