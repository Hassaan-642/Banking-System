//
// Created by UM3R on 24/05/2022.
//

#ifndef OOPLAB_FINAL_EMPLOYEE_H
#define OOPLAB_FINAL_EMPLOYEE_H
#include "Person.h"
#include "AccountHolder.h"
class Employee: virtual public Person{
protected:
    int empId;
    std::string email;
    std::string pass;
public:

    Employee();

    virtual void Login();
    void Create();
    void Update();
    void Delete();
    void deposit();

    int getEmpId() const;

    void setEmpId(int empId);

    const string &getEmail() const;

    void setEmail(const string &email);

    const string &getPass() const;

    void setPass(const string &pass);

    void withdraw();
    void SearchAccount();
};


#endif //OOPLAB_FINAL_EMPLOYEE_H
