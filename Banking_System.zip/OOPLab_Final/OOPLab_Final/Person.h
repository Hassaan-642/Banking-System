//
// Created by arees on 23/05/2022.
//

#ifndef OOPLAB_FINAL_PERSON_H
#define OOPLAB_FINAL_PERSON_H
#include <cstring>
#include <string>
using namespace std;

class Person {
protected:
    std::string FName;
    std::string MName;


protected:
    std::string LName;
    std::string CNIC;
    std::string Address;
    std::string TeleNum;
    std::string DOB;
    std::string Date;
    std::string userName;
    std::string Pass;


public:

    Person();
    void setFName(string fname);
    void setMName(string mname);
    void setLName(string lname);
    void setCNIC(string cnic);
    void setAddress(string address);
    void setTeleNum(string telenum);
    void setDOB(string dob);
    void setDate(string date);
    virtual void login();

    const string getFName() const;

    const string getMName() const;

    const string getLName() const;

    const string getCnic() const;

    const string getAddress() const;

    const string getTeleNum() const;

    const string getDob() const;

    const string getDate() const;


};


#endif //OOPLAB_FINAL_PERSON_H
