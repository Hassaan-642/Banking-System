

#ifndef OOPLAB_FINAL_CCARDTYPE_H
#define OOPLAB_FINAL_CCARDTYPE_H
#include <string>


class CCardType {
protected:
    std::string cardName;
    int cardLimit;
    std::string CardNum;
public:
   virtual int getMonthlyInterest()=0;



    int getCardLimit() const;

    void setCardLimit(int cardLimit);

    const std::string &getCardNum() const;

    void setCardNum(const std::string &cardNum);
    void setCardName();


    CCardType();

    CCardType(int cardLimit, const std::string &cardNum);

};


#endif //OOPLAB_FINAL_CCARDTYPE_H
