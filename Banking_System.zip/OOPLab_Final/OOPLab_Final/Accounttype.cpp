

#include "Accounttype.h"

Accounttype::Accounttype(int minAccBalance, int totalInterest, int govtTaxIntrst) : minAccBalance(minAccBalance),
                                                                                    TotalInterest(totalInterest),
                                                                                    GovtTaxIntrst(govtTaxIntrst) {}
int Accounttype:: getTotalInterest()
{
    return 2;
}

int Accounttype::getMinAccBalance() const {
    return minAccBalance;
}

void Accounttype::setMinAccBalance() {
    Accounttype::minAccBalance = 1000;
}

void Accounttype::setTotalInterest(int totalInterest) {
    TotalInterest = totalInterest;
}
int Accounttype::getTotalInterest() 
{
     return TotalInterest;
}

int Accounttype::getGovtTaxIntrst() const {
    return GovtTaxIntrst;
}

void Accounttype::setGovtTaxIntrst(int govtTaxIntrst) {
    GovtTaxIntrst = govtTaxIntrst;
}

Accounttype::Accounttype() {}

