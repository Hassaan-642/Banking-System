

#include "AccountHolder.h"
#include "VisaCard.h"
#include "MasterCard.h"
#include "LocalCard.h"
#include "SavingAccount.h"
#include "CheckingAccount.h"


AccountHolder::~AccountHolder() {

}

const Accounttype &AccountHolder::getAccType() const {
    return *AccType;
}

void AccountHolder::setAccType(Accounttype *accType) {
    AccType = (Accounttype *) accType;
}

int AccountHolder::getAcctype() const {
    return Acctype;
}


int AccountHolder::getCardType() const {
    return CardType;
}

void AccountHolder::setCardType(int cardType) {
    srand(time(0));
    if (cardType == 1)
        Cdetails=new VisaCard(50000, to_string(rand()%9999999999+1111111111));
    else if (cardType == 2)
        Cdetails = new MasterCard;
    else if (cardType == 3)
        Cdetails = new LocalCard;
}


void AccountHolder::setAccType(int actype) {
   if(actype==1)
    AccType = new SavingAccount;
    else
        AccType =new CheckingAccount(2000,18,6);
}

AccountHolder::AccountHolder() {
FName="";
}

void AccountHolder::Deposit(int d) 
{
   Deposit=d;
}

void AccountHolder::WithDraw(doublw w) 
{
    WithDraw=w;
}

void AccountHolder::getMiniStatement() const {

}

void AccountHolder::getTransactionHistory() {

}
double AccountHolder::getDeposit()
{
     return Deposit;
}
double AccountHolder::getWithDraw()
{
    return WithDraw;
}



