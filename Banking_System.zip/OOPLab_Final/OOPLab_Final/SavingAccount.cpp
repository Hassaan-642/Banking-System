//
// Created by UM3R on 24/05/2022.
//

#include "SavingAccount.h"

int SavingAccount::getTotalInterest() {

    return 1;
}
