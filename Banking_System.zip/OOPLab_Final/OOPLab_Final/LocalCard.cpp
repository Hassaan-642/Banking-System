//
// Created by UM3R on 24/05/2022.
//

#include "LocalCard.h"

int LocalCard::getMonthlyInterest()
{
    return 123;
}

LocalCard::LocalCard() : CCardType(cardLimit, CardNum) {}
