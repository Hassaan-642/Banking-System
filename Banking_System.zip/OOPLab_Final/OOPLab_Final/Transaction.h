//
// Created by UM3R on 24/05/2022.
//

#ifndef OOPLAB_FINAL_TRANSACTION_H
#define OOPLAB_FINAL_TRANSACTION_H

#include "AccountHolder.h"
class Transaction {

public:
    void write();
};


#endif //OOPLAB_FINAL_TRANSACTION_H
