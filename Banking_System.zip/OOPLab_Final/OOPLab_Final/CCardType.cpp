
#include "CCardType.h"
CCardType::CCardType(int cardLimit, const std::string &cardNum) : cardLimit(cardLimit), CardNum(cardNum) {}

CCardType::CCardType() {}

int CCardType::getCardLimit() const {
    return cardLimit;
}

void CCardType::setCardLimit(int cardLimit) {
    CCardType::cardLimit = cardLimit;
}

const std::string &CCardType::getCardNum() const {
    return CardNum;
}

void CCardType::setCardNum(const std::string &cardNum) {
    CardNum = cardNum;
}