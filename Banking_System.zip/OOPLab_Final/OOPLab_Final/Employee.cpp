//
// Created by UM3R on 24/05/2022.
//

#include "Employee.h"
#include <fstream>
#include <iostream>

void Employee::Login() {
    std::string email1;
    std::string pass1;

    std::cout << "enter the login credentials" << std::endl;
    std::cout << "username: ";
    std::cin >> this->email;
    std::cout << "password: ";
    std::cin >> this->pass;
    fstream file1;
    file1.open("Admin.dat", ios::in);
    while (!file1.eof()) {
        file1 >> email1 >> pass1;
        if (email == email1 && pass == pass1)
            system("CLS");
        cout << "Welcome to Employee Portal" << endl;
        break;
    }
}

void Employee::Create()
{
    fstream file;
    file.open("Users.dat",ios::app);
    AccountHolder* a;
}

void Employee::Update() {

}

void Employee::deposit() {

}

void Employee::SearchAccount() {

}

void Employee::Delete() {

}

void Employee::withdraw() {

}

int Employee::getEmpId() const {
    return empId;
}



void Employee::setEmpId(int empId) {
    Employee::empId = empId;
}

const string &Employee::getEmail() const {
    return email;
}

void Employee::setEmail(const string &email) {
    Employee::email = email;
}

const string &Employee::getPass() const {
    return pass;
}

void Employee::setPass(const string &pass) {
    Employee::pass = pass;
}

Employee::Employee() {

}

