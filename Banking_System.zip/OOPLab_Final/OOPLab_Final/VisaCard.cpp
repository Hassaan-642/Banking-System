//
// Created by UM3R on 24/05/2022.
//

#include "VisaCard.h"

int VisaCard::getMonthlyInterest()
{
    return 1;
}
VisaCard::VisaCard(int cardLimit, const std::string &cardNum) : CCardType(cardLimit, cardNum) {
}
void VisaCard::frequentUsagePoints(int i)
{
frequentUsagePoints=i;
}
void VisaCard::calculateFUP(int c)
{
calculateFUP=c;
}
int VisaCard::frequentUsagePoints()
{
return frequentUsagePoints;
}
int VisaCard::calculateFUP()
{
return calculateFUP;
}