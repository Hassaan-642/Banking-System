#include <iostream>
#include "AccountHolder.h"
#include "Accounttype.h"
#include "SavingAccount.h"
#include "Employee.h"

using namespace std;
int main() {
    int choice;

   cout<<"Welcome To Air Banking System"<<endl;
   cout<<"///////////////////////////////////////////////////"<<endl;
   cout<<"//////////////////Login Screen/////////////////////"<<endl;
   cout<<"///////////////////////////////////////////////////"<<endl;
   cout<<"\n\nSelection option to Continue:\n";
   cout<<"Log in as:\n";
   cout<<"1- Account holder\n";
   cout<<"2- Bank Employee\n";
   cin>>choice;
   if(choice==1){
       AccountHolder Acc;
       Acc.login();
       cout<<"Selection the option to perform operation:\n";
       cout<<"";
       Acc.Deposit();
       Acc.withdraw();
       Acc.getMiniStatement();
   }
   else if(choice==2){
       Employee Acc;
       Acc.Login();
       cout<<"Selection the option to perform operation:\n";
       cout<<"1- Create new account"<<endl;
       cout<<"2- Update account"<<endl;
       cout<<"3- Delete Account"<<endl;
       cout<<"4- Deposit money "<<endl;
       cout<<"5- WithDraw money"<<endl;
       Acc.
   }
   SavingAccount a;
   a.setMinAccBalance();
   cout<<a.getMinAccBalance();
}
