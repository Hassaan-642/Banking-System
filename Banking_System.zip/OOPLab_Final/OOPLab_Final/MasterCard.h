//
// Created by UM3R on 24/05/2022.
//

#ifndef OOPLAB_FINAL_MASTERCARD_H
#define OOPLAB_FINAL_MASTERCARD_H
#include "CCardType.h"

class MasterCard :public CCardType{
public:
    MasterCard();

    virtual int getMonthlyInterest();

    MasterCard(int cardLimit, const std::string &cardNum);
};


#endif //OOPLAB_FINAL_MASTERCARD_H
