//
// Created by UM3R on 24/05/2022.
//

#ifndef OOPLAB_FINAL_VISACARD_H
#define OOPLAB_FINAL_VISACARD_H
#include "CCardType.h"

class VisaCard : public CCardType{
public:
    virtual int getMonthlyInterest();
    int frequentUsagePoints;
    int calculateFUP;
    VisaCard(int cardLimit, const std::string &cardNum);
    void frequentUsagePoints(int);
    int frequentUsagePoints();
    void calculateFUP(int);
    int calculateFUP();
    VisaCard();
};
#endif //OOPLAB_FINAL_VISACARD_H
