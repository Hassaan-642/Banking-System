//
// Created by UM3R on 24/05/2022.
//

#include "MasterCard.h"

MasterCard::MasterCard() {}

int MasterCard::getMonthlyInterest() {
   // return CCardType::getMonthlyInterest();
    return 3;
}

MasterCard::MasterCard(int cardLimit, const std::string &cardNum) : CCardType(cardLimit, cardNum) {}
