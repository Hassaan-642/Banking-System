//
// Created by UM3R on 24/05/2022.
//

#ifndef OOPLAB_FINAL_SAVINGACCOUNT_H
#define OOPLAB_FINAL_SAVINGACCOUNT_H
#include "Accounttype.h"

class SavingAccount : virtual public Accounttype{
public:
    virtual int getTotalInterest();

};


#endif //OOPLAB_FINAL_SAVINGACCOUNT_H
