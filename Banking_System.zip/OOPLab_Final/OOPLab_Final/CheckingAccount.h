//
// Created by UM3R on 24/05/2022.
//

#ifndef OOPLAB_FINAL_CHECKINGACCOUNT_H
#define OOPLAB_FINAL_CHECKINGACCOUNT_H
#include "Accounttype.h"

class CheckingAccount:public Accounttype{
public:
virtual int getTotalInterest();

    CheckingAccount();

    CheckingAccount(int minAccBalance, int totalInterest, int govtTaxIntrst);
};


#endif //OOPLAB_FINAL_CHECKINGACCOUNT_H
