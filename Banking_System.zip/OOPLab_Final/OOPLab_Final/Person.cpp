//
// Created by arees on 23/05/2022.
//

#include "Person.h"
#include <cstring>
using namespace std;

void Person::login() {

}
void Person::setFName(string fname)
{
    FName=fname;
}

void Person::setMName(string mname)
{
    MName=mname;
}

void Person::setLName(string lname)
{
    LName=lname;
}

void Person::setTeleNum(string telenum)
{
    TeleNum=telenum;
}
void Person::setCNIC(string cnic)
{
    CNIC=cnic;
}

void Person::setDOB(string dob)
{
    DOB=dob;
}

void Person::setDate(string date)
{
    Date=date;
}
const string Person::getFName() const {
    return FName;
}

const string Person::getMName() const {
    return MName;
}

const string Person::getLName() const {
    return LName;
}

const string Person::getCnic() const {
    return CNIC;
}

const string Person::getAddress() const {
    return Address;
}

const string Person::getTeleNum() const {
    return TeleNum;
}

const string Person::getDob() const {
    return DOB;
}

const string Person::getDate() const {
    return Date;
}



Person::Person() {}
