

#ifndef OOPLAB_FINAL_ACCOUNTTYPE_H
#define OOPLAB_FINAL_ACCOUNTTYPE_H


class Accounttype {
private:
    int minAccBalance;
    int TotalInterest;
    int GovtTaxIntrst;
public:
    virtual int getTotalInterest();

    int getMinAccBalance() const;

    void setMinAccBalance();

    void setTotalInterest(int totalInterest);

    int getGovtTaxIntrst() const;

    void setGovtTaxIntrst(int govtTaxIntrst);

    Accounttype(int minAccBalance, int totalInterest, int govtTaxIntrst);

    Accounttype();
};


#endif //OOPLAB_FINAL_ACCOUNTTYPE_H
